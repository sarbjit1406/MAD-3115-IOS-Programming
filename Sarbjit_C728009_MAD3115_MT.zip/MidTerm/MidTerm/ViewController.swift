//
//  ViewController.swift
//  MidTerm
//
//  Created by MacStudent on 2018-08-14.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblOddEven: UILabel!
    
    @IBOutlet weak var lblCount: UILabel!
    
    let oddEvenNo = [29, 43, 14, 30, 51, 23]
    var Click = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnEven(_ sender: Any) {
        Click += 1
        lblCount.text = "click count : \(Click)"
        let randomNumber: Int = Int(arc4random_uniform(6))
        for Num: Int in oddEvenNo{
            if Num % 2 == 0{
                print("\(Num) Even")
                
            }
            else{
                print("\(Num) Odd")
    
          }
        }
    }
}
func btnOdd(_ sender: Any) {
       
    }


