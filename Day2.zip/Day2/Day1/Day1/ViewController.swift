//
//  ViewController.swift
//  Day1
//
//  Created by MacStudent on 2018-08-04.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    

    @IBOutlet weak var lblDisplayName: UILabel!
    @IBOutlet weak var lblDisplayPassword: UILabel!
    
    @IBOutlet weak var txtFldName: UITextField!
    @IBOutlet weak var txtFldPassword: UITextField!
    
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var btnRegister: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func registerButtonAction(_ sender: Any) {
        
    }
    @IBAction func loginButtonAction(_ sender: Any) {
        let clickedButton = sender as! UIButton
        if clickedButton.tag == 1{
            btnRegister.isHidden = false
            btnLogin.isHidden = true
        }else if clickedButton.tag == 2{
            btnRegister.isHidden = true
            btnLogin.isHidden = false
        }
        
        lblDisplayName.text = txtFldName.text
        lblDisplayPassword.text = txtFldPassword.text
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

