//
//  RegisterVC.swift
//  Day1
//
//  Created by MacStudent on 2018-08-04.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class RegisterVC: UIViewController {

    @IBOutlet weak var lblName: UILabel!
    
    @IBOutlet weak var lblAddress: UILabel!
    
    @IBOutlet weak var lblDOB: UILabel!
    
    @IBOutlet weak var lblEmail: UILabel!
    
    @IBOutlet weak var lblGender: UILabel!
    
    @IBOutlet weak var lblUserName: UILabel!
    
    @IBOutlet weak var lblPasswod: UILabel!
    
    @IBOutlet weak var txtFldName: UITextField!
    
    @IBOutlet weak var txtFldAddress: UITextField!
    
    @IBOutlet weak var txtFldEmail: UITextField!
    
    @IBOutlet weak var txtFldUserName: UITextField!
    
    @IBOutlet weak var txtFldPassword: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func registerButtonAction(_ sender: Any) {
        
    }
    
    // segmentClickEvent
    @IBAction func genderSegmentedAction(_ sender: Any) {
        let sgmtBtn = sender as! UISegmentedControl
        switch sgmtBtn.selectedSegmentIndex  {
        case 0:
            print("First is selected")
        case 1:
             print("Second is selected")
        default:
            print("Invalid selection")
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
