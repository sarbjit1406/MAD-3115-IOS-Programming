//
//  ViewController.swift
//  LoginForm
//
//  Created by MacStudent on 2018-08-04.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var lblUsername: UILabel!
    
    @IBOutlet weak var segmentedButton: UISegmentedControl!
    @IBOutlet weak var btnRegister: UIButton!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var txtFldPassword: UITextField!
    @IBOutlet weak var txtFldUsername: UITextField!
    @IBOutlet weak var lblPassword: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    @IBAction func loginButtonAction(_ sender: Any) {
        let clickedButton = sender as! UIButton
        if clickedButton.tag == 1 {
            btnRegister.isHidden = false
            btnLogin.isHidden = true
        } else if clickedButton.tag == 2 {
            btnRegister.isHidden = true
            btnLogin.isHidden = false
        }
    }
    
    
    @IBAction func segmentClickEvent(_ sender: Any) {
        let sgmntBtn = sender as! UISegmentedControl
        if sgmntBtn.tag == 3{
//            switch sgmntBtn.selectedSegmentIndex {
//                case 0:
//                    print("First is selected")
//                case 1:
//                    print("Second is selected")
//                default:
//                    print("Fun ho gya")
//                }
        
                if sgmntBtn.selectedSegmentIndex == 0 {
                    print("First is selected")
                } else if sgmntBtn.selectedSegmentIndex == 1 {
                    print("Second is selected")
                } else {
                    print("Fun ho gya")
                }
        } else if sgmntBtn.tag == 4{
            print("Kuch vi")
        }
    }
    
    @IBAction func normalSegmentControl(_ sender: Any) {
        let segment = sender as! UISegmentedControl
        print("Selected segment is: \(segment.selectedSegmentIndex)")
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    
    
    
    
    
    
    
    


}

