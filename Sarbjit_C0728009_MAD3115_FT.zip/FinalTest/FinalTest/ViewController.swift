//
//  ViewController.swift
//  FinalTest
//
//  Created by MacStudent on 2018-08-18.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var btnTerm1: UIButton!
    @IBOutlet weak var btnTerm2: UIButton!
    @IBOutlet weak var btnTerm3: UIButton!
    @IBOutlet weak var btnTerm4: UIButton!
    
    @IBOutlet weak var lblTerm1: UILabel!
    @IBOutlet weak var lblTerm2: UILabel!
    @IBOutlet weak var lblTerm3: UILabel!
    @IBOutlet weak var lblTerm4: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnTerm1(_ sender: Any) {
        
        let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let termGpaVC = mainSB.instantiateViewController(withIdentifier: "SecondScene")
        navigationController?.pushViewController(termGpaVC, animated: true)
    }
    

    @IBAction func btnTerm2(_ sender: Any) {
        let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let termGpaVC = mainSB.instantiateViewController(withIdentifier: "SecondScene")
        navigationController?.pushViewController(termGpaVC, animated: true)
    }
    
    @IBAction func btnTerm3(_ sender: Any) {
        let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let termGpaVC = mainSB.instantiateViewController(withIdentifier: "SecondScene")
        navigationController?.pushViewController(termGpaVC, animated: true)
    }
    
    @IBAction func btnTerm4(_ sender: Any) {
        let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let termGpaVC = mainSB.instantiateViewController(withIdentifier: "SecondScene")
        navigationController?.pushViewController(termGpaVC, animated: true)
    }
}

