//
//  TermGpaVC.swift
//  FinalTest
//
//  Created by MacStudent on 2018-08-18.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class TermGpaVC: UIViewController {
    
    @IBOutlet weak var lblSubject1: UILabel!
    @IBOutlet weak var lblSubject2: UILabel!
    @IBOutlet weak var lblSubject3: UILabel!
    @IBOutlet weak var lblSubject4: UILabel!
    @IBOutlet weak var lblSubject5: UILabel!
    
    @IBOutlet weak var txtSubject1: UITextField!
    @IBOutlet weak var txtSubject2: UITextField!
    @IBOutlet weak var txtSubject3: UITextField!
    @IBOutlet weak var txtSubject4: UITextField!
    @IBOutlet weak var txtSubject5: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func CalculateGPA(_ sender: Any) {
        let subject1 = Int(txtSubject1.text!)
        let subject2 = Int(txtSubject2.text!)
        let subject3 = Int(txtSubject3.text!)
        let subject4 = Int(txtSubject4.text!)
        let subject5 = Int(txtSubject5.text!)
        
        let total =  subject1! + subject2! + subject3! + subject4! + subject5!
        let average = total / 2
        var finalGrade : String
        if (average >= 94){
            finalGrade = "A+"
        }else{
            
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
