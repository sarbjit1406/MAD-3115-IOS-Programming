//
//  GpaVc.swift
//  GPAcalculator
//
//  Created by MacStudent on 2018-08-18.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class GpaVc: UIViewController {
    @IBOutlet weak var sub1grade: UITextField!
    
    @IBOutlet weak var sub1gpa: UITextField!
    
    @IBOutlet weak var sub4grade: UITextField!
    @IBOutlet weak var sub3grade: UITextField!
    @IBOutlet weak var sub2grade: UITextField!
    @IBOutlet weak var sub1: UITextField!
    @IBOutlet weak var sub2: UITextField!
    @IBOutlet weak var sub3: UITextField!
    @IBOutlet weak var sub4: UITextField!
    @IBOutlet var sub5grade: UIView!
    @IBOutlet weak var sub5: UITextField!
    @IBOutlet weak var finalGpa: UILabel!
    @IBAction func CalculateGpa(_ sender: Any) {
        var grade1 = Int(sub1.text!)
        if (grade1!>=94){
        
        }
        var grade2 = Int(sub2.text!)
        var grade3 = Int(sub3.text!)
        var grade4 = Int(sub4.text!)
        var grade5 = Int(sub5.text!)
        
        var totalgrade = grade1!+grade2!+grade3!+grade4!+grade5!
        var avg = totalgrade/5
        var gpa : String
        
        if (avg>=94){
            finalGpa.text = "GPA is 4.00"
        }else if(avg<94 && avg>=87){
            finalGpa.text = "GPA is 3.7"
            
        }else if(avg<87 && avg>=80){
            finalGpa.text = "GPA is 3.5"
            
        }else if(avg<80 && avg>=77){
            finalGpa.text = "GPA is 3.2"
            
        }else if(avg<77 && avg>=73){
            finalGpa.text = "GPA is 3.0"
            
        }else if(avg<73 && avg>=70){
            finalGpa.text = "GPA is 2.7"
            
        }else if(avg<70 && avg>=67){
            finalGpa.text = "GPA is 2.3"
            
        }else if(avg<67 && avg>=63){
            finalGpa.text = "GPA is 2.0"
            
        }else if(avg<63 && avg>=60){
            finalGpa.text = "GPA is 1.7"
            
        }else if(avg<60 && avg>=50){
            finalGpa.text = "GPA is 1.0"
            
        }else if(avg<50 && avg>=0){
            finalGpa.text = "GPA is 0.0"
        }
}
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
