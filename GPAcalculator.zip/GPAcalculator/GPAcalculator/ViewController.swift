//
//  ViewController.swift
//  GPAcalculator
//
//  Created by MacStudent on 2018-08-18.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func Term4(_ sender: Any) {
        let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let GpaVc = mainSB.instantiateViewController(withIdentifier: "TermGPA")
        navigationController?.pushViewController(GpaVc, animated: true)
    }
    @IBAction func Term3(_ sender: Any) {
        let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let GpaVc = mainSB.instantiateViewController(withIdentifier: "TermGPA")
        navigationController?.pushViewController(GpaVc, animated: true)
    }
    @IBAction func Term2(_ sender: Any) {
        let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let GpaVc = mainSB.instantiateViewController(withIdentifier: "TermGPA")
        navigationController?.pushViewController(GpaVc, animated: true)
    }
   @IBAction func Term1(_ sender: Any) {
        let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
       let GpaVc = mainSB.instantiateViewController(withIdentifier: "TermGPA")
       navigationController?.pushViewController(GpaVc, animated: true)
   }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

